
function toggleMessage() {
  const msg = document.getElementById("message");
  msg.style.display = msg.style.display === "none" ? "block" : "none";
}
